package me.mohsinali.smartvotingsystem.DTO;

/**
 * Created by SPIDER on 5/4/2018.
 */

public class Candidate {
    public String id;
    public String name;
    public String description;
    public String noOfVotes;
    public String status;
    public void setName(String n)
    {
        name=n;
    }
    public String getName()
    {
        return name;
    }
    public void setDescription(String des)
    {
        description=des;
    }
    public String getDescription()
    {
        return description;
    }
    public void setNoOfVotes(String votes)
    {
        noOfVotes=votes;
    }
    public String getNoOfVotes()
    {
        return noOfVotes;
    }
    public void setStatus(String stat)
    {
        status=stat;
    }
    public String getStatus()
    {
        return status;
    }
    public void setId(String i)
    {
        id=i;
    }
    public String getId()
    {
        return id;
    }


}

