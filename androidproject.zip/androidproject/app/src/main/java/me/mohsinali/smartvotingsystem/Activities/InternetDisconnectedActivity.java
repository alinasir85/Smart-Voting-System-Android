package me.mohsinali.smartvotingsystem.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import me.mohsinali.smartvotingsystem.R;

public class InternetDisconnectedActivity extends AppCompatActivity {


    Button btn_tryagain_internet_disconnected_activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internet_disconnected);

        btn_tryagain_internet_disconnected_activity = findViewById(R.id.btn_tryagain_internet_disconnected_activity);

        btn_tryagain_internet_disconnected_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(InternetDisconnectedActivity.this, MainActivity.class);
                startActivity(intent1);
                finish();
            }
        });
    }
}
