package me.mohsinali.smartvotingsystem.DTO;

import java.io.Serializable;

public class options implements Serializable {
    private String description;
    private String noOfVotes;
    private String optionID;
    private String pollID;
    private String status;
    private String title;

    public options() {
    }

    public options(String description, String noOfVotes, String optionID, String pollID, String status, String title) {
        this.description = description;
        this.noOfVotes = noOfVotes;
        this.optionID = optionID;
        this.pollID = pollID;
        this.status = status;
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNoOfVotes() {
        return noOfVotes;
    }

    public void setNoOfVotes(String noOfVotes) {
        this.noOfVotes = noOfVotes;
    }

    public String getOptionID() {
        return optionID;
    }

    public void setOptionID(String optionID) {
        this.optionID = optionID;
    }

    public String getPollID() {
        return pollID;
    }

    public void setPollID(String pollID) {
        this.pollID = pollID;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
