package me.mohsinali.smartvotingsystem.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import me.mohsinali.smartvotingsystem.DTO.VotingModule;
import me.mohsinali.smartvotingsystem.R;

/**
 * Created by SPIDER on 5/4/2018.
 */

public class VotingModuleAdapter extends RecyclerView.Adapter<VotingModuleAdapter.MyViewHolder> {

    private List<VotingModule> votingModuleList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView moduleName;
        public TextView question;
        //public TextView details;
        public TextView startTime;
        public TextView endTime;
        public TextView pollID;
        public TextView createdBy;

        public MyViewHolder(View view) {
            super(view);
            moduleName = (TextView) view.findViewById(R.id.stats_castedVotes_pollname_votingModule);
            question = (TextView) view.findViewById(R.id.stats_castedVotes_pollQuestion_votingModule);
            //details = (TextView) view.findViewById(R.id.tv6);
            startTime = (TextView) view.findViewById(R.id.stats_castedVotes_startTime_votingModule);
            endTime = (TextView) view.findViewById(R.id.stats_castedVotes_endTime_votingModule);
            pollID = (TextView) view.findViewById(R.id.stats_castedVotes_pollid_votingModule);
            createdBy = (TextView) view.findViewById(R.id.stats_castedVotes_createdby_votingModule);

        }
    }

    public VotingModuleAdapter(List<VotingModule> votingModList) {
        this.votingModuleList = votingModList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.votingmodulecell, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        VotingModule vm = votingModuleList.get(position);
        String v = vm.getName();

        holder.moduleName.setText(vm.getName());
        holder.question.setText(vm.getQuestion());
        //holder.details.setText(vm.getDetails());
        holder.startTime.setText(vm.getStartDate().toString().substring(0, 19));
        holder.endTime.setText(vm.getEndDate().toString().substring(0, 19));
        holder.pollID.setText(vm.getId());
        holder.createdBy.setText(vm.getCreatedBy());
    }

    @Override
    public int getItemCount() {
        return votingModuleList.size();
    }
}