package me.mohsinali.smartvotingsystem.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

String email_cnic;
    private EditText name;
    private EditText password;
    private EditText email;
    private EditText age;
    private EditText nationality;
    private EditText country;
    private EditText city;
    private EditText cnic;
    private Button btn;
   // DatabaseReference databaseUsers;

    SharedPreferences sp;
    DatabaseReference databaseUsers;
    boolean flag=false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);
        setTitle("Register ");


        sp= PreferenceManager.getDefaultSharedPreferences(this);
       // databaseUsers = FirebaseDatabase.getInstance().getReference("users");
        name=(EditText)findViewById(R.id.name);
        password=(EditText)findViewById(R.id.password);
        email=(EditText)findViewById(R.id.email);
        age=(EditText)findViewById(R.id.age);
        country=(EditText)findViewById(R.id.country);
        city=(EditText)findViewById(R.id.city);
        nationality=(EditText)findViewById(R.id.nationality);

       cnic=(EditText)findViewById(R.id.cnic);
      email.setOnFocusChangeListener(new View.OnFocusChangeListener() {
          @Override
          public void onFocusChange(View v, boolean hasFocus) {
              if(!hasFocus)
              {
                  String e=email.getText().toString();
                  String validemail = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +"\\@" +"[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +"(" +"\\." +"[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +")+";
                  if(!TextUtils.isEmpty(e)) {
                      Matcher matcher = Pattern.compile(validemail).matcher(e);
                      if (!matcher.matches()) {
                         // Toast.makeText(getApplicationContext(), "Enter the correct Email", Toast.LENGTH_SHORT).show();
                          email.setError("Enter the correct Email");
                      }
                  }

              }
          }
      });
       cnic.addTextChangedListener(new TextWatcher() {
           int length=0;
           @Override
           public void beforeTextChanged(CharSequence s, int start, int count, int after) {
               String str=cnic.getText().toString();
               length=str.length();

           }

           @Override
           public void onTextChanged(CharSequence s, int start, int before, int count) {
               String str=cnic.getText().toString();
               if((str.length()==5 && length <str.length()) || (str.length()==13 && length <str.length())) {
                   //checking length  for backspace.
                   cnic.append("-");
               }

           }

           @Override
           public void afterTextChanged(Editable s) {

           }
       });
        btn = findViewById(R.id.nextBtn);
        btn.setOnClickListener(this);


    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
    public void onClick(View v) {
        Log.i("CHK", "AA");
        Log.e("CHK", "AA");
        if (v.getId() == R.id.nextBtn) {



            Log.i("CHK", "BB");
            Log.e("CHK", "BB");
            String n=name.getText().toString();
            String p=password.getText().toString();
            String e=email.getText().toString();
            String nic=cnic.getText().toString();
            String a=age.getText().toString();
           // int a=Integer.parseInt(age.getText().toString()) ;
            Log.e("Age",a);
            String nat=nationality.getText().toString();
            String count=country.getText().toString();
            String cit=city.getText().toString();
            Log.i("CHK", "oo");
            Log.e("CHK", "oo");



           if(TextUtils.isEmpty(n)||TextUtils.isEmpty(p)||TextUtils.isEmpty(e)||TextUtils.isEmpty(nic)||a==""||TextUtils.isEmpty(nat)||TextUtils.isEmpty(count)||TextUtils.isEmpty(cit))
            {

                       Toast.makeText(getApplicationContext(),"Fill all the space",Toast.LENGTH_SHORT).show();
            }
            else
           {



               Toast.makeText(getApplicationContext(), "Wait", Toast.LENGTH_LONG).show();
               databaseUsers = FirebaseDatabase.getInstance().getReference("users");
               databaseUsers.addValueEventListener(new ValueEventListener() {
                   @Override
                   public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                       for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {

                           Object o = postSnapshot.getValue();
                           HashMap u = (HashMap) o;

                           Object o2 = u.get("email");
                           String db_email = String.valueOf(o2);

                           o2 = u.get("cnic");
                           String db_cnic = String.valueOf(o2);


                           if (db_email.equals(e)  || db_cnic.equals(nic)) {
                               flag=true;
                               Log.e("db-email", db_email);
                               Log.e("db-cnic", db_cnic);
                               break;
                           }
                       }
                       if(flag==true)
                       {
                           Intent i = new Intent(RegisterActivity.this, ExistingUserActivity.class);

                           Log.e("existing", "user");




                           startActivity(i);

                       }
                       else
                       {
                           email_cnic=e + "_" + nic;
                           Log.e("email_cnic :  ", email_cnic);
                           SharedPreferences.Editor ed=sp.edit();
                           ed.putString("Name",n);
                           ed.putString("Password",p);
                           ed.putString("Email",e);
                           ed.putString("CNIC",nic);
                           int ag=Integer.parseInt(age.getText().toString()) ;

                           ed.putInt("Age",ag);
                           ed.putString("Nationality",nat);
                           ed.putString("Country",count);
                           ed.putString("City",cit);
                           ed.putString("Email_Cnic",email_cnic);
                           ed.commit();
                           // Users u=new Users(3,n,p,e,"",nic,a,nat);
                           databaseUsers.removeEventListener(this);

                           Intent in = new Intent(RegisterActivity.this, EmailValidationActivity.class);



                           startActivity(in);

                       }
                   }

                   @Override
                   public void onCancelled(@NonNull DatabaseError databaseError) {

                   }
               });

           }

        }

    }
}
