package me.mohsinali.smartvotingsystem.DTO;

public class users {
    public String name;
    public String email;
    public String city;
    public String cnic;
    public String email_cnic;
    public String country;
    public int age;
    public String nationality;
    public String password;
    public String picture;
    public String userID;
    public String loggedin;

    public users() {
    }

    public String getLoggedin() {
        return loggedin;
    }

    public void setLoggedin(String loggedin) {
        this.loggedin = loggedin;
    }

    public users(String name, String email, String city, String cnic, String email_cnic, String country, int age, String nationality, String password, String picture, String userID) {
        this.name = name;
        this.email = email;
        this.city = city;
        this.cnic = cnic;
        this.email_cnic=email_cnic;
        this.country = country;
        this.age = age;
        this.nationality = nationality;
        this.password = password;
        this.picture = picture;
        this.userID = userID;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCnic() {
        return cnic;
    }

    public void setCnic(String cnic) {
        this.cnic = cnic;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    public String getCity() {
        return city;
    }

    public void setEmail_cnic(String email_cnic) {
        this.city = email_cnic;
    }
    public String getEmail_cnic()
    {
        return email_cnic;
    }
}
