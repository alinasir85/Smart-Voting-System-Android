package me.mohsinali.smartvotingsystem.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.Executors;

import me.mohsinali.smartvotingsystem.Adapters.OptionsAdapter;
import me.mohsinali.smartvotingsystem.DTO.Poll;
import me.mohsinali.smartvotingsystem.DTO.options;
import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

public class OptionsActivity extends AppCompatActivity {
    private ArrayList<options> optionsList = new ArrayList<options>();
    // private List<options> temp = new ArrayList<>();
    private RecyclerView recyclerView;
    private OptionsAdapter oAdapter;
    private FirebaseDatabase database;
    private DatabaseReference ref;
    private String pid;
    private Poll poll;
    private Context c = this;
    private String formattedDate;
    private String status = "Pending";
    private ProgressDialog loadingDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.stats_options);
        setTitle("Options");
        poll = (Poll) getIntent().getExtras().getSerializable("poll");
        pid = poll.getPollID();
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        formattedDate = df.format(cal.getTime());

        Date today = null;
        Date pollDate = null;

        try {
            today = df.parse(formattedDate);
            pollDate = df.parse(poll.getEndTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }

        int f = today.compareTo(pollDate);

        if (f > 0) {
            status = "Complete";
        }

    /*    loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);

        loadingDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);

        loadingDialog.setMessage("Options Loading ");
        loadingDialog.show();*/


        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                setOptionList(c);
            }
        });

        /*Intent intent = getIntent();
        Bundle args = intent.getBundleExtra("BUNDLE");
        optionsList = (ArrayList<options>) args.getSerializable("ARRAYLIST");*/

    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }

    public void setOptionList(Context context) {

        database = FirebaseDatabase.getInstance();
        ref = database.getReference("options");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                optionsList.clear();

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    options option = new options();
                    Object o = postSnapshot.getValue();
                    HashMap u = (HashMap) o;

                    Object o2 = u.get("pollID");
                    String pollid = String.valueOf(o2);
                    if (pollid.equals(pid)) {

                        option.setPollID(String.valueOf(o2));
                        o2 = u.get("title");
                        option.setTitle(String.valueOf(o2));
                        o2 = u.get("optionID");
                        option.setOptionID(String.valueOf(o2));
                        o2 = u.get("description");
                        option.setDescription(String.valueOf(o2));
                        //o2 = u.get("status");
                        option.setStatus(status);
                        o2 = u.get("noOfVotes");
                        option.setNoOfVotes(String.valueOf(o2));

                        optionsList.add(option);
                        //oAdapter.notifyDataSetChanged();
                    }
                }

                Collections.sort(optionsList, new Comparator<options>() {
                    public int compare(options s1, options s2) {
                        int votes1 = Integer.parseInt(s1.getNoOfVotes());
                        int votes2 = Integer.parseInt(s2.getNoOfVotes());
                        return votes2 - votes1;

                    }
                });

                // Collections.reverse(optionsList);

                //oAdapter.notifyDataSetChanged();
                recyclerView = findViewById(R.id.stats_options_recycler_view);
                oAdapter = new OptionsAdapter(optionsList);
                recyclerView.setHasFixedSize(true);
                RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                recyclerView.setLayoutManager(mLayoutManager);
                recyclerView.setItemAnimator(new DefaultItemAnimator());
                recyclerView.setAdapter(oAdapter);
                // adding inbuilt divider line
                recyclerView.addItemDecoration(new DividerItemDecoration(context, LinearLayoutManager.VERTICAL));

                // adding custom divider line with padding 16dp
                // recyclerView.addItemDecoration(new MyDividerItemDecoration(this, LinearLayoutManager.HORIZONTAL, 16));
                recyclerView.setItemAnimator(new DefaultItemAnimator());


                // optionsList=temp;
                oAdapter.notifyDataSetChanged();
               // loadingDialog.hide();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


  /*  public void updateStatus()
    {
        database=FirebaseDatabase.getInstance();
        ref=database.getReference("options");

    }*/
}
