package me.mohsinali.smartvotingsystem.Activities;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

public class MainActivity extends AppCompatActivity {

    Button btn_login_main_activity;
    Button btn_register_main_activity;

    final private int PERMISSION_REQUEST_CODE_NETWORK_ACCESS = 123;
    final private int PERMISSION_REQUEST_CODE_INTERNET = 124;
    final private int PERMISSION_REQUEST_CODE_READ_EXTERNAL_STORAGE = 125;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        setTitle("Smart Voting System");
        askForPermission(Manifest.permission.INTERNET, PERMISSION_REQUEST_CODE_INTERNET, "You need to allow access to Internet");
        askForPermission(Manifest.permission.ACCESS_NETWORK_STATE, PERMISSION_REQUEST_CODE_NETWORK_ACCESS, "You need to allow access to Network State");
        askForPermission(Manifest.permission.READ_EXTERNAL_STORAGE, PERMISSION_REQUEST_CODE_READ_EXTERNAL_STORAGE, "You need to allow access to External Storage");


        SharedPreferences sp = getSharedPreferences("user", Context.MODE_PRIVATE);
        String CurrentUserID = sp.getString("UserID", "");
        if (CurrentUserID.length() > 0) {
            Intent i = new Intent(MainActivity.this, HomeActivity.class);
            i.putExtra("CurrentUser", CurrentUserID);
            startActivity(i);
            finish();
        }


        btn_login_main_activity = findViewById(R.id.btn_login_main_activity);
        btn_register_main_activity = findViewById(R.id.btn_register_main_activity);

        btn_login_main_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        btn_register_main_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
    private void askForPermission(String permissionName, int permissionRequestCode, String askMessage) {
        int hasPermission = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            hasPermission = checkSelfPermission(permissionName);
        }
        if (hasPermission != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!shouldShowRequestPermissionRationale(permissionName)) {
                    showMessageOKCancel(askMessage,
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        requestPermissions(new String[]{permissionName}, permissionRequestCode);
                                    }
                                }
                            });
                    return;
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{permissionName},
                        permissionRequestCode);
            }
            return;
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(MainActivity.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE_NETWORK_ACCESS:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(MainActivity.this, " Permission Granted", Toast.LENGTH_SHORT)
                            .show();
                    // Permission Granted put your code here
                } else {
                    // Permission Denied
                    Toast.makeText(MainActivity.this, "Permission Denied", Toast.LENGTH_SHORT)
                            .show();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
