package me.mohsinali.smartvotingsystem.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executors;

import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;
import me.mohsinali.smartvotingsystem.DTO.VotingModule;
import me.mohsinali.smartvotingsystem.Adapters.VotingModuleAdapter;


public class VotingModulesActivity extends AppCompatActivity {
    private List<VotingModule> vm = new ArrayList<>();
    private ArrayList validModulesID= new ArrayList<>();
    static public ArrayList usersAlreadyVoted= new ArrayList<>();
    static   public ArrayList usersList= new ArrayList<>();
    public android.support.v7.widget.RecyclerView recyclerView;
    private VotingModuleAdapter vmAdapter;
    private VotingModule vmTemp;
    FirebaseDatabase database;
    DatabaseReference myRef ;
    static public String loggedInUserID;

    private ProgressDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_votingmodules);
        setTitle("All polls");
        SharedPreferences sp = getSharedPreferences("user", Context.MODE_PRIVATE);
        loggedInUserID= sp.getString("UserID", "");

        loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);

        loadingDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);

        //loggedInUserID="5";

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view_votingModule);

        vmAdapter = new VotingModuleAdapter(vm);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());

        // adding inbuilt divider line
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                vmTemp = vm.get(position);
                // Toast.makeText(getApplicationContext(), vmTemp.getName() + " is selected!", Toast.LENGTH_SHORT).show();
                new AlertDialog.Builder(VotingModulesActivity.this)

                        .setTitle("Details Of The Poll")
                        .setMessage(vmTemp.getDescription())
                        .setCancelable(true)
                        .setPositiveButton("Start Voting", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent i= new Intent(VotingModulesActivity.this,CandidateMainActivity.class);
                                i.putExtra("ID",vmTemp.getId());
                                i.putExtra("indexInDB",vmTemp.indexInDB);
                                usersAlreadyVoted=vmTemp.usersAlreadyVoted;
                                usersList=vmTemp.usersList;
                                startActivity(i);
                            }


                        }).show();

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
        // Write a message to the database
        database = FirebaseDatabase.getInstance();

        //       prepareSampleCandidateData();
        recyclerView.setAdapter(vmAdapter);
        // prepareSampleCandidateData();
        loadingDialog.setMessage("Loading, Please wait... ");
        loadingDialog.show();

        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                getDataFromDatabase();
            }
        });
        //vmAdapter.notifyDataSetChanged();

        //getDataFromDatabase();
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
    private void getDataFromDatabase()
    {
        myRef = database.getReference("poll");


        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                Object o = dataSnapshot.getValue();
                HashMap u = (HashMap) o;
                Log.i("A", "onChildAddeduL: "+u.get("usersList"));
                Log.i("B", "onChildAdded:UAV "+u.get("usersAlreadyVoted"));

                VotingModule vm1 = new VotingModule();
                vm1.setName((String) u.get("title"));
                vm1.setDescription((String) u.get("details"));
                vm1.setQuestion((String) u.get("pollQuestion"));
                vm1.setCreatedBy(String.valueOf(u.get("createdBy")));
                vm1.indexInDB=dataSnapshot.getKey();
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                vm1.setStartDate(new Date());
                vm1.setId(String.valueOf(u.get("pollID")));

                //Date d= new Date();
                //String toStoreInDB= dateFormat.format(d).toString();

                try {
                    vm1.setStartDate(dateFormat.parse((String) u.get("startTime")));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                try {
                    vm1.setendDate(dateFormat.parse((String) u.get("endTime")));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                //checks a users is valid for tha module or not by checking in the list
                Object obj1= u.get("usersList");
                if(!(obj1 instanceof  ArrayList))
                {
                    vm1.usersList= new ArrayList(((HashMap)obj1).values());
                }
                else
                {
                    vm1.usersList=(ArrayList) obj1;

                }
                Object obj2= u.get("usersAlreadyVoted");

                if(!(obj2 instanceof  ArrayList))
                {
                    vm1.usersAlreadyVoted= new ArrayList(((HashMap)obj2).values());
                }
                else
                {
                    vm1.usersAlreadyVoted=(ArrayList) obj2;
                }

                //checks a module is still online for voting or not
                Date d= new Date();
                if(d.after(vm1.getStartDate())&&d.before(vm1.getEndDate())&&vm1.usersList.contains(loggedInUserID)) {
                    vm.add(vm1);
                    recyclerView.setAdapter(vmAdapter);
                }
                loadingDialog.hide();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                Object o = dataSnapshot.getValue();
                HashMap u = (HashMap) o;
                String idd=String.valueOf(u.get("pollID"));
                for (VotingModule v:vm) {
                    if(v.id.equals(idd))
                    {
                        Toast.makeText(getApplicationContext(), "MODULES UPDATED", Toast.LENGTH_SHORT).show();
                        finish();
                        myRef.removeEventListener(this);
                    }
                }
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void prepareSampleCandidateData() {





        VotingModule vm1 = new VotingModule();
        vm1.setName("Voting For Best Actor");
        vm1.setDescription("Vote For the best");
        // vm1.setOrganization("ACTORS.com");
        vm1.setStartDate(new Date());
        vm1.setendDate(new Date());
        vm1.setId("1");
        vm.add(vm1);

        VotingModule vm2 = new VotingModule();
        vm2.setName("Manager Selection");
        vm2.setDescription("Vote For the best");
        //  vm2.setOrganization("abc.Org");
        vm2.setStartDate(new Date());
        vm2.setendDate(new Date());
        vm2.setId("2");
        vm.add(vm2);

        VotingModule vm3 = new VotingModule();
        vm3.setName("Best laptop 2018");
        vm3.setDescription("Vote For best tech");
        //   vm3.setOrganization("RANKING.pk");
        vm3.setStartDate(new Date());
        vm3.setendDate(new Date());
        vm3.setId("3");
        vm.add(vm3);
        // notify adapter about data set changes
        // so that it will render the list with new data
        vmAdapter.notifyDataSetChanged();
    }
}