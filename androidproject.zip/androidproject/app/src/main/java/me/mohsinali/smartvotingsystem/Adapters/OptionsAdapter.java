package me.mohsinali.smartvotingsystem.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import me.mohsinali.smartvotingsystem.DTO.options;
import me.mohsinali.smartvotingsystem.R;

public class OptionsAdapter extends RecyclerView.Adapter<OptionsAdapter.MyViewHolder> {


    private List<options> optionsLists;

    public OptionsAdapter(List<options> optionsLists) {
        this.optionsLists = optionsLists;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView oid;
        public TextView description;
        public TextView noOfVotes;
        public TextView status;
        public TextView title;


        public MyViewHolder(View view) {
            super(view);
            oid = view.findViewById(R.id.stats_options_oid);
            description = view.findViewById(R.id.stats_options_description);
            noOfVotes = view.findViewById(R.id.stats_options_votes);
            status = view.findViewById(R.id.stats_options_status);
            title = view.findViewById(R.id.stats_options_title);

        }
    }


    @Override
    public OptionsAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.stats_options_cell, parent, false);

        return new OptionsAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(OptionsAdapter.MyViewHolder holder, int position) {

        options o = optionsLists.get(position);
        holder.description.setText(o.getDescription());
        holder.oid.setText(o.getOptionID());
        holder.title.setText(o.getTitle());
        holder.status.setText(o.getStatus());
        holder.noOfVotes.setText(o.getNoOfVotes());


    }

    @Override
    public int getItemCount() {
        return optionsLists.size();
    }
}