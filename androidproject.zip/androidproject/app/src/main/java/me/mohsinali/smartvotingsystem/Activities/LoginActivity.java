package me.mohsinali.smartvotingsystem.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.concurrent.Executors;

import me.mohsinali.smartvotingsystem.DTO.users;
import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

public class LoginActivity extends AppCompatActivity {
    Button btn_login_login_activity;
    EditText et_email, et_pass;
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference("users");
    SharedPreferences sp;
    boolean emailFound=false;
    private ProgressDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);
        setTitle("Login");


        loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);

        loadingDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);


        sp = getSharedPreferences("user", Context.MODE_PRIVATE);

        btn_login_login_activity = findViewById(R.id.btn_login_login_activity);
        et_email = findViewById(R.id.et_email_login_activity);
        et_pass = findViewById(R.id.et_password_login_activity);
        btn_login_login_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String login = et_email.getText().toString();
                final String pass = et_pass.getText().toString();

                if (TextUtils.isEmpty(login)) {
                    Toast.makeText(LoginActivity.this, "Enter Email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(pass)) {
                    Toast.makeText(LoginActivity.this, "Enter Password", Toast.LENGTH_SHORT).show();
                    return;
                }
                loadingDialog.setMessage("Logging In, Please wait... ");
                loadingDialog.show();

                Executors.newSingleThreadExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        signIn();
                    }
                });

            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
    public void validateSignIn()
    {
        final String login = et_email.getText().toString();

        ref.orderByChild("email").equalTo(login).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    public void signIn() {

        final String login = et_email.getText().toString();
        final String pass = et_pass.getText().toString();
        final users CurrentUser = new users();
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Object o = postSnapshot.getValue();
                    HashMap u = (HashMap) o;


                    Object o2 = u.get("password");
                    String password = String.valueOf(o2);
                    o2 = u.get("email");
                    String email = String.valueOf(o2);

                    Object loggedin = u.get("loggedin");
                    String loggedinS = String.valueOf(loggedin);



                    Log.d("post email", email);
                    Log.d("post pass", password);


                    if (email.equals(login) && password.equals(pass) && loggedinS.equals("false")) {


                        SharedPreferences.Editor ed = sp.edit();
                        ed.putString("Password", password);
                        ed.putString("Email", email);

                        o2 = u.get("userID");
                        String uID = String.valueOf(o2);
                        ed.putString("UserID", uID);

                        DatabaseReference  databaseUsers = FirebaseDatabase.getInstance().getReference("users");



                        o2 = u.get("age");
                        int age = (Integer.parseInt(String.valueOf(o2)));
                        ed.putInt("Age", age);

                        o2 = u.get("name");
                        String name = String.valueOf(o2);
                        ed.putString("Name", name);

                        o2 = u.get("city");
                        String city = String.valueOf(o2);
                        ed.putString("City", city);

                        o2 = u.get("cnic");
                        String cnic = String.valueOf(o2);
                        ed.putString("CNIC", cnic);

                        o2 = u.get("country");
                        String country = String.valueOf(o2);
                        ed.putString("Country", country);

                        o2 = u.get("nationality");
                        String n = String.valueOf(o2);
                        ed.putString("Nationality", n);

                        o2 = u.get("picture");
                        String p = String.valueOf(o2);
                        ed.putString("Picture", p);
                        if (ed.commit()) {
                            databaseUsers.child(uID).child("loggedin").setValue("true");

                            loadingDialog.hide();
                            emailFound=true;

                            Toast.makeText(LoginActivity.this,"Logged in as "+ name, Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);


                            startActivity(intent);

                            finish();
                            //Toast.makeText(getApplicationContext(), "Authenticated", Toast.LENGTH_SHORT).show();
                        }
                    } else if(email.equals(login)) {
                        emailFound=true;
                        loadingDialog.hide();
                        if(!(password.equals(pass)))
                        {
                            Toast.makeText(getApplicationContext(), "Invalid Password", Toast.LENGTH_SHORT).show();
                        }

                        else {
                            Toast.makeText(getApplicationContext(), "Already logged in", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    }
                    //loadingDialog.hide();


                }
                if(emailFound==false)
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        loadingDialog.hide();
                        Toast.makeText(LoginActivity.this, "Invalid Email", Toast.LENGTH_SHORT).show();
                    }
                });
                ref.removeEventListener(this);
                emailFound=false;

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
     /*  ref.child("email").equalTo(login).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                Object o = dataSnapshot.getValue();
                HashMap u = (HashMap) o;


                Object o2 = u.get("password");
                String password = String.valueOf(o2);
                o2 = u.get("email");
                String email = String.valueOf(o2);

                Object loggedin = u.get("loggedin");
                String loggedinS = String.valueOf(loggedin);



                Log.d("post email", email);
                Log.d("post pass", password);


                if (email.equals(login) && password.equals(pass) && loggedinS.equals("false")) {


                    SharedPreferences.Editor ed = sp.edit();
                    ed.putString("Password", password);
                    ed.putString("Email", email);

                    o2 = u.get("userID");
                    String uID = String.valueOf(o2);
                    ed.putString("UserID", uID);

                    DatabaseReference  databaseUsers = FirebaseDatabase.getInstance().getReference("users");
                    databaseUsers.child(uID).child("loggedin").setValue("true");



                    o2 = u.get("age");
                    int age = (Integer.parseInt(String.valueOf(o2)));
                    ed.putInt("Age", age);

                    o2 = u.get("name");
                    String name = String.valueOf(o2);
                    ed.putString("Name", name);

                    o2 = u.get("city");
                    String city = String.valueOf(o2);
                    ed.putString("City", city);

                    o2 = u.get("cnic");
                    String cnic = String.valueOf(o2);
                    ed.putString("CNIC", cnic);

                    o2 = u.get("country");
                    String country = String.valueOf(o2);
                    ed.putString("Country", country);

                    o2 = u.get("nationality");
                    String n = String.valueOf(o2);
                    ed.putString("Nationality", n);

                    o2 = u.get("picture");
                    String p = String.valueOf(o2);
                    ed.putString("Picture", p);
                    if (ed.commit()) {
                        loadingDialog.hide();
                        Toast.makeText(LoginActivity.this, name, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);


                        startActivity(intent);

                        finish();
                        Toast.makeText(getApplicationContext(), "Authenticated", Toast.LENGTH_SHORT).show();
                    }
                } else {

                    loadingDialog.hide();
                    flag=false;
                    if(!(password.equals(pass)))
                    {
                        Toast.makeText(getApplicationContext(), "Retry Password", Toast.LENGTH_SHORT).show();


                    }

                    else {
                        Toast.makeText(getApplicationContext(), "Already logged in", Toast.LENGTH_SHORT).show();
                    }
                }
                //loadingDialog.hide();


            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(LoginActivity.this, "Database retrieval failed", Toast.LENGTH_SHORT).show();


            }

        });*/
        //loadingDialog.hide();




       // Toast.makeText(LoginActivity.this, "Invalid Email", Toast.LENGTH_SHORT).show();
    }

}


