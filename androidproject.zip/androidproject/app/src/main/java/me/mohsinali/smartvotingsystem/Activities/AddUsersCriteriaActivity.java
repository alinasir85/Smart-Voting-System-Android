package me.mohsinali.smartvotingsystem.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executors;

import me.mohsinali.smartvotingsystem.DTO.Poll;
import me.mohsinali.smartvotingsystem.DTO.options;
import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

public class AddUsersCriteriaActivity extends AppCompatActivity {


    private static final String TAG = "AddUserCriteriaActivity";
    private Intent intent;

    private FirebaseDatabase database;
    private DatabaseReference ref;
    private Poll poll;
    private List<options> optionsList;
    private List<String> userIDs;

    private EditText user_criteria_email_et;
    private EditText user_criteria_country_et;
    private EditText user_criteria_city_et;
    private Button create_poll_btn;

    List<String> emailDomainsList;
    List<String> countriesList;
    List<String> citiesList;

    private ProgressDialog loadingDialog;

    SharedPreferences sp;
    String CurrentUserID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_users_criteria);
        setTitle("Add Users Criteria");
        sp = getSharedPreferences("user", Context.MODE_PRIVATE);


        CurrentUserID = sp.getString("UserID", "");

        loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);
        loadingDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);

        user_criteria_email_et = findViewById(R.id.user_criteria_email_et);
        user_criteria_country_et = findViewById(R.id.user_criteria_country_et);
        user_criteria_city_et = findViewById(R.id.user_criteria_city_et);

        create_poll_btn = findViewById(R.id.create_poll_btn);

        intent = getIntent();
        Bundle pollBundle = intent.getBundleExtra("POLL_BUNDLE");
        poll = (Poll) pollBundle.getSerializable("POLL_MODEL");
        optionsList = (List<options>) pollBundle.getSerializable("POLL_OPTIONS_ARRAY");


        create_poll_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emailDomainsList = Arrays.asList(TextUtils.split(user_criteria_email_et.getText().toString().trim(), ","));
                countriesList = Arrays.asList(TextUtils.split(user_criteria_country_et.getText().toString().trim(), ","));
                citiesList = Arrays.asList(TextUtils.split(user_criteria_city_et.getText().toString().trim(), ","));

                if (isAllFieldsValid()) {
                    loadingDialog.setMessage("Creating Poll, Please wait... ");
                    loadingDialog.show();

                    Executors.newSingleThreadExecutor().execute(new Runnable() {
                        @Override
                        public void run() {
                            findUserIds();
                        }
                    });
                }

            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
    private boolean isAllFieldsValid() {
        boolean allFieldsValid = true;

        if (emailDomainsList.size() == 0 && countriesList.size() == 0 && citiesList.size() == 0) {
            Toast.makeText(this, "No user exists with given above criteria", Toast.LENGTH_SHORT).show();
            user_criteria_email_et.requestFocus();
            allFieldsValid = false;
        }
        return allFieldsValid;
    }

    public void findUserIds() {
        userIDs = new ArrayList<>();

        database = FirebaseDatabase.getInstance();
        ref = database.getReference("users");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Object o = postSnapshot.getValue();
                    HashMap u = (HashMap) o;


                    Object o2 = u.get("userID");
                    String userID = String.valueOf(o2);

                    o2 = u.get("email");
                    String userEmail = String.valueOf(o2);

                    o2 = u.get("city");
                    String userCity = String.valueOf(o2);

                    o2 = u.get("country");
                    String userCountry = String.valueOf(o2);

                    for (String emailDomain : emailDomainsList) {
                        if (userEmail.toLowerCase().indexOf(emailDomain.trim().toLowerCase()) != -1 && !userIDs.contains(userID) && userID != CurrentUserID) {
                            userIDs.add(userID);
                        }
                    }
                    for (String country : countriesList) {
                        if (TextUtils.equals(userCountry.toLowerCase(), country.toLowerCase()) && !userIDs.contains(userID) && userID != CurrentUserID) {
                            userIDs.add(userID);
                        }
                    }
                    for (String city : citiesList) {
                        if (TextUtils.equals(userCity.toLowerCase(), city.toLowerCase()) && !userIDs.contains(userID) && userID != CurrentUserID) {
                            userIDs.add(userID);
                        }
                    }

                }

                Log.d(TAG, "Fetched UserIDs from firebase: " + userIDs.toString());

                if (userIDs.size() == 0) {
                    loadingDialog.hide();
                    Toast.makeText(getApplicationContext(), "No candidate exists with provided criteria", Toast.LENGTH_SHORT).show();
                } else {
                    ref.removeEventListener(this);

                    savePoll();

                    Intent intent1 = new Intent(AddUsersCriteriaActivity.this, HomeActivity.class);
                    startActivity(intent1);
                    loadingDialog.hide();
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }



    public void savePoll() {
        Log.d(TAG, "SavePoll() called");

        database = FirebaseDatabase.getInstance();

        // inserting poll
        ref = database.getReference("poll");

        final String pollID = ref.push().getKey();
        poll.setPollID(pollID);


        poll.setCreatedBy(CurrentUserID);
        poll.setUsersList(userIDs);
        ArrayList<String> usersAlreadyVoted = new ArrayList<>();
        usersAlreadyVoted.add("0");
        poll.setUsersAlreadyVoted(usersAlreadyVoted);

        ref.child(pollID).setValue(poll);

        Log.d(TAG, "Inserted Poll" + pollID);

        Log.d(TAG, "Inserting poll options");

        // inserting options
        ref = database.getReference("options");

        for (options o : optionsList) {

            final String optionID = ref.push().getKey();

            o.setOptionID(optionID);
            o.setPollID(pollID);
            o.setNoOfVotes("0");
            o.setStatus("InProgress");

            ref.child(optionID).setValue(o);

            Log.d(TAG, "Inserted poll option: " + o.getTitle());

        }
        Toast.makeText(getApplicationContext(), "Poll Inserted Successfully", Toast.LENGTH_SHORT).show();

    }
}
