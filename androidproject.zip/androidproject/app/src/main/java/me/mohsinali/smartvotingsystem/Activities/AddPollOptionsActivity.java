package me.mohsinali.smartvotingsystem.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import me.mohsinali.smartvotingsystem.DTO.Poll;
import me.mohsinali.smartvotingsystem.DTO.options;
import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

public class AddPollOptionsActivity extends AppCompatActivity {

    List<PollOptionViewHolder> mPollOptions = new ArrayList<PollOptionViewHolder>();
    List<options> optionsList = new ArrayList<>();

    LinearLayout ll_poll_options_wrapper_add_poll_options_activity;
    LinearLayout ll_addbtn_add_poll_options_activity;

    ScrollView sv_options_add_poll_options_activity;
    Button btn_adduserscriteria_add_poll_activity;

    Poll poll;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_poll_options);

        setTitle("Add Poll Options");

        ll_addbtn_add_poll_options_activity = findViewById(R.id.ll_addbtn_add_poll_options_activity);
        ll_poll_options_wrapper_add_poll_options_activity = findViewById(R.id.ll_poll_options_wrapper_add_poll_options_activity);

        sv_options_add_poll_options_activity = findViewById(R.id.sv_options_add_poll_options_activity);
        btn_adduserscriteria_add_poll_activity = findViewById(R.id.btn_adduserscriteria_add_poll_activity);

        ll_addbtn_add_poll_options_activity.setOnClickListener(v -> {
            addPollOptionEditText(true);
            sv_options_add_poll_options_activity.fullScroll(View.FOCUS_DOWN);
        });
        addPollOptionEditText(true);

        intent = getIntent();
        if (intent != null)
            poll = intent.getBundleExtra("POLL_BUNDLE").getParcelable("POLL_MODEL");

        btn_adduserscriteria_add_poll_activity.setOnClickListener(v -> {
            optionsList = new ArrayList<>();
            for (int i = 0; i < mPollOptions.size(); i++) {
                if (!mPollOptions.get(i).isEmptyOption()) {
                    String optionTitle = mPollOptions.get(i).et_option_title.getText().toString();
                    String optionDescription = mPollOptions.get(i).et_option_description.getText().toString();
                    optionsList.add(new options(optionDescription, "", "", "", "", optionTitle));
                }
            }
            if (isAllFieldsValid()) {
                Intent intent2 = new Intent(AddPollOptionsActivity.this, AddUsersCriteriaActivity.class);

                Bundle pollBundle = intent.getBundleExtra("POLL_BUNDLE");
                if (pollBundle != null) {
                    pollBundle.putSerializable("POLL_OPTIONS_ARRAY", (Serializable) optionsList);
                    intent2.putExtra("POLL_BUNDLE", pollBundle);
                    startActivity(intent2);
                } else {
                    Toast.makeText(getApplicationContext(), "Error occur", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
    private void addPollOptionEditText(boolean focus) {
        View v = LayoutInflater.from(this).inflate(R.layout.polloption_field, null);
        ll_poll_options_wrapper_add_poll_options_activity.addView(v);

        PollOptionViewHolder optionHolder = new PollOptionViewHolder(mPollOptions.size(), v);
        optionHolder.iv_poll_delete.setOnClickListener(v1 -> {
            ll_poll_options_wrapper_add_poll_options_activity.removeView(v);
            mPollOptions.remove(optionHolder.index);
            for (int i = optionHolder.index; i < mPollOptions.size(); i++) {
                mPollOptions.get(i).index = i;
                mPollOptions.get(i).tv_poll_option_no.setText(("Option #" + (i + 1)));
            }
        });
        if (focus) {
            optionHolder.et_option_title.requestFocus();
        }

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {

                int emptyOptions = 0;
                for (int i = 0; i < mPollOptions.size(); i++) {
                    if (mPollOptions.get(i).isEmptyOption()) {
                        emptyOptions++;
                    }
                }

                if (emptyOptions == 0) {
                    addPollOptionEditText(false);
                }
            }
        };

        optionHolder.et_option_title.addTextChangedListener(textWatcher);
        optionHolder.et_option_description.addTextChangedListener(textWatcher);


        mPollOptions.add(optionHolder);
    }

    private boolean isAllFieldsValid() {
        boolean allFieldsValid = true;
        if (optionsList.size() <= 1) {
            Toast.makeText(this, "Please add atleast 2 options", Toast.LENGTH_SHORT).show();
            allFieldsValid = false;
        }
        return allFieldsValid;
    }

    public static class PollOptionViewHolder {
        public int index;
        public TextView tv_poll_option_no;
        public EditText et_option_title;
        public EditText et_option_description;
        public ImageView iv_poll_delete;

        PollOptionViewHolder(int index, View v) {
            this.index = index;
            tv_poll_option_no = v.findViewById(R.id.tv_poll_option_no);
            tv_poll_option_no.setText("Option #" + (index + 1));
            et_option_title = v.findViewById(R.id.et_option_title);
            et_option_description = v.findViewById(R.id.et_option_description);
            iv_poll_delete = v.findViewById(R.id.iv_poll_delete);
        }

        boolean isEmptyOption() {
            return et_option_title.getText().toString().isEmpty() || et_option_description.getText().toString().isEmpty();
        }
    }
}
