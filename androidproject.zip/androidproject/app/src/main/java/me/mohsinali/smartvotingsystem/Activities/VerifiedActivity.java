package me.mohsinali.smartvotingsystem.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

public class VerifiedActivity extends AppCompatActivity implements View.OnClickListener {

    int backpress;
    ImageButton btn;

    // DataSnapshot snapshot;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_verified);
        // FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        btn = (ImageButton) findViewById(R.id.goLogin);
        btn.setOnClickListener(this);

        // databaseUsers.child("3").setValue(user);
       /* int size = 0;
        for (DataSnapshot postSnapshot : snapshot.getChildren()) {
            size++ ;
        }*/
        // Log.i("Chck", "Size: "+size);
     /* long size=snapshot.getChildrenCount();
        Log.i("Chck", "Size: "+size);*/
        // Toast.makeText(getApplicationContext(),"id"+id +"ref:"+databaseUsers,Toast.LENGTH_LONG).show();


    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
   /* public void onBackPressed() {

        backpress = backpress + 1;
        Toast.makeText(getApplicationContext(), " Press Back again to Exit ", Toast.LENGTH_SHORT).show();

        if (backpress > 1) {
            // this.finish();
            super.onBackPressed();
        }
    }*/

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.goLogin) {
            Intent i = new Intent(VerifiedActivity.this, LoginActivity.class);
            startActivity(i);
        }

    }
}


