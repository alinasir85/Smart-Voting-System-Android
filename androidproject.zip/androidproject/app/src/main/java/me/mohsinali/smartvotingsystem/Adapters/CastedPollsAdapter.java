package me.mohsinali.smartvotingsystem.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import me.mohsinali.smartvotingsystem.DTO.Poll;
import me.mohsinali.smartvotingsystem.R;

/**
 * Created by LINO on 01/05/2018.
 */

public class CastedPollsAdapter extends RecyclerView.Adapter<CastedPollsAdapter.MyViewHolder> {

    private List<Poll> PollsList;

    public CastedPollsAdapter(List<Poll> PollsList) {
        this.PollsList = PollsList;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView name;
        public TextView description;
        public TextView createdby;
        public TextView id;
        public TextView question;
        public TextView startTime;
        public TextView endTime;


        public MyViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.stats_castedVotes_pollname);
            description = view.findViewById(R.id.stats_castedVotes_description);
            createdby = view.findViewById(R.id.stats_castedVotes_createdby);
            id = view.findViewById(R.id.stats_castedVotes_pollid);
            question = view.findViewById(R.id.stats_castedVotes_pollQuestion);
            startTime = view.findViewById(R.id.stats_castedVotes_startTime);
            endTime = view.findViewById(R.id.stats_castedVotes_endTime);
        }
    }


    @Override
    public CastedPollsAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.stats_casted_votes_cells, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(CastedPollsAdapter.MyViewHolder holder, int position) {

        Poll p = PollsList.get(position);
        holder.name.setText(p.getTitle());
        holder.description.setText(p.getDetails());
        holder.createdby.setText(p.getCreatedBy());
        holder.id.setText(p.getPollID());
        holder.question.setText(p.getPollQuestion());
        holder.startTime.setText(p.getStartTime());
        holder.endTime.setText(p.getEndTime());


    }

    @Override
    public int getItemCount() {
        return PollsList.size();
    }
}

