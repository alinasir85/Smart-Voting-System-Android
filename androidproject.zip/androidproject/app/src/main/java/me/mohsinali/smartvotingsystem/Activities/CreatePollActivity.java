package me.mohsinali.smartvotingsystem.Activities;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.format.DateFormat;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import me.mohsinali.smartvotingsystem.DTO.Poll;
import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

//import com.takisoft.datetimepicker.DatePickerDialog;
//import com.takisoft.datetimepicker.TimePickerDialog;

public class CreatePollActivity extends AppCompatActivity {

    EditText et_title_create_poll_activity;
    EditText et_question_create_poll_activity;
    EditText et_description_create_poll_activity;

    DatePickerDialog dpd_start_time, dpd_end_time;
    TimePickerDialog tpd_start_time, tpd_end_time;

    Button btn_pick_start_time_create_poll_activity;
    Button btn_pick_end_time_create_poll_activity;

    Button btn_next_create_poll_activity;

    Calendar start_time = Calendar.getInstance();
    Calendar end_time = Calendar.getInstance();

    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_poll);
        setTitle("Create Poll");


        et_title_create_poll_activity = findViewById(R.id.et_title_create_poll_activity);
        et_question_create_poll_activity = findViewById(R.id.et_question_create_poll_activity);
        et_description_create_poll_activity = findViewById(R.id.et_description_create_poll_activity);

        btn_pick_start_time_create_poll_activity = findViewById(R.id.btn_pick_start_time_create_poll_activity);
        btn_pick_end_time_create_poll_activity = findViewById(R.id.btn_pick_end_time_create_poll_activity);
        btn_next_create_poll_activity = findViewById(R.id.btn_next_create_poll_activity);

        Poll poll = new Poll();

        // PICK START TIME init:
        tpd_start_time = new TimePickerDialog(CreatePollActivity.this, (view1, hourOfDay, minute) -> {
            //  Toast.makeText(CreatePollActivity.this, String.format("%02d", hourOfDay) + ":" + String.format("%02d", minute), Toast.LENGTH_SHORT).show();
            start_time.set(start_time.get(Calendar.YEAR), start_time.get(Calendar.MONTH), start_time.get(Calendar.DAY_OF_MONTH), hourOfDay, minute);


            String formatted = format.format(start_time.getTime());
            poll.setStartTime(formatted);
            btn_pick_start_time_create_poll_activity.setText(formatted);

        }, start_time.get(Calendar.HOUR_OF_DAY), start_time.get(Calendar.MINUTE), DateFormat.is24HourFormat(CreatePollActivity.this));


        dpd_start_time = new DatePickerDialog(CreatePollActivity.this, (view1, year, month, dayOfMonth) -> {
            //  Toast.makeText(CreatePollActivity.this, String.format("%d", year) + "-" + String.format("%02d", month + 1) + "-" + String.format("%02d", dayOfMonth), Toast.LENGTH_SHORT).show();
            start_time.set(year, month, dayOfMonth);
            tpd_start_time.show();
        }, start_time.get(Calendar.YEAR), start_time.get(Calendar.MONTH), start_time.get(Calendar.DATE));


        // PICK END TIME init:
        tpd_end_time = new TimePickerDialog(CreatePollActivity.this, (view1, hourOfDay, minute) -> {
            //  Toast.makeText(CreatePollActivity.this, String.format("%02d", hourOfDay) + ":" + String.format("%02d", minute), Toast.LENGTH_SHORT).show();
            end_time.set(end_time.get(Calendar.YEAR), end_time.get(Calendar.MONTH), end_time.get(Calendar.DAY_OF_MONTH), hourOfDay, minute);

            String formatted = format.format(end_time.getTime());
            btn_pick_end_time_create_poll_activity.setText(formatted);
            poll.setEndTime(formatted);
        }, end_time.get(Calendar.HOUR_OF_DAY), end_time.get(Calendar.MINUTE), DateFormat.is24HourFormat(CreatePollActivity.this));


        dpd_end_time = new DatePickerDialog(CreatePollActivity.this, (view1, year, month, dayOfMonth) -> {
            //  Toast.makeText(CreatePollActivity.this, String.format("%d", year) + "-" + String.format("%02d", month + 1) + "-" + String.format("%02d", dayOfMonth), Toast.LENGTH_SHORT).show();
            end_time.set(year, month, dayOfMonth);
            tpd_end_time.show();
        }, end_time.get(Calendar.YEAR), end_time.get(Calendar.MONTH), end_time.get(Calendar.DATE));

        btn_pick_start_time_create_poll_activity.setOnClickListener(v -> dpd_start_time.show());
        btn_pick_end_time_create_poll_activity.setOnClickListener(v -> dpd_end_time.show());
        btn_next_create_poll_activity.setOnClickListener(v -> {
            if (isAllFieldsValid()) {
                Intent i = new Intent(CreatePollActivity.this, AddPollOptionsActivity.class);

                poll.setTitle(et_title_create_poll_activity.getText().toString());
                poll.setPollQuestion(et_question_create_poll_activity.getText().toString());
                poll.setDetails(et_description_create_poll_activity.getText().toString());

                Bundle pollBundle = new Bundle();
                pollBundle.putSerializable("POLL_MODEL", poll);
                i.putExtra("POLL_BUNDLE", pollBundle);
                startActivity(i);
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();

        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }

    private boolean isAllFieldsValid() {
        boolean allFieldsValid = true;

        if (et_title_create_poll_activity.getText().toString().length() == 0) {
            Toast.makeText(this, "Please fill out Poll Title", Toast.LENGTH_SHORT).show();
            et_title_create_poll_activity.requestFocus();
            allFieldsValid = false;
        } else if (et_question_create_poll_activity.getText().toString().length() == 0) {
            Toast.makeText(this, "Please fill out Poll Question", Toast.LENGTH_SHORT).show();
            et_question_create_poll_activity.requestFocus();
            allFieldsValid = false;
        } else if (et_description_create_poll_activity.getText().toString().length() == 0) {
            Toast.makeText(this, "Please fill out Poll Question", Toast.LENGTH_SHORT).show();
            et_description_create_poll_activity.requestFocus();
            allFieldsValid = false;
        } else if (btn_pick_start_time_create_poll_activity.getText().toString().toLowerCase().equals("pick time")) {
            Toast.makeText(this, "Please pick start time", Toast.LENGTH_SHORT).show();
            btn_pick_start_time_create_poll_activity.requestFocus();
            allFieldsValid = false;
        } else if (btn_pick_end_time_create_poll_activity.getText().toString().toLowerCase().equals("pick time")) {
            Toast.makeText(this, "Please pick end time", Toast.LENGTH_SHORT).show();
            btn_pick_end_time_create_poll_activity.requestFocus();
            allFieldsValid = false;
        } else if (start_time.getTimeInMillis() >= end_time.getTimeInMillis()) {
            Toast.makeText(this, "Please pick valid start & end time", Toast.LENGTH_SHORT).show();
            allFieldsValid = false;
        }
        return allFieldsValid;
    }


}
