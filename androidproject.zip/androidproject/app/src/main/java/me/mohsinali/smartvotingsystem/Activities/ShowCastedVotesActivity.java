package me.mohsinali.smartvotingsystem.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import me.mohsinali.smartvotingsystem.Adapters.CastedPollsAdapter;
import me.mohsinali.smartvotingsystem.DTO.Poll;
import me.mohsinali.smartvotingsystem.DTO.users;
import me.mohsinali.smartvotingsystem.DTO.usersForPoll;
import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

/**
 * Created by LINO on 01/05/2018.
 */

public class ShowCastedVotesActivity extends AppCompatActivity {
    private List<Poll> pollList = new ArrayList<>();
    private RecyclerView recyclerView;
    private CastedPollsAdapter pAdapter;
    SharedPreferences sp;
    private String userid;
    private FirebaseDatabase database;
    private DatabaseReference ref;
    private users user = new users();
    private usersForPoll u;
    private ProgressDialog loadingDialog;

    ArrayList<String> pollids = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.stats_created_polls);
        setTitle("Voted Polls");

        sp = getSharedPreferences("user", Context.MODE_PRIVATE);
        userid = sp.getString("UserID", "");
       /* Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                pollIds();
            }
        });
*/
        pollids = getIntent().getExtras().getStringArrayList("pollid");


        recyclerView = findViewById(R.id.stats_polls_recycler_view);

        pAdapter = new CastedPollsAdapter(pollList);

        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(pAdapter);
        // adding inbuilt divider line
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        // adding custom divider line with padding 16dp
        // recyclerView.addItemDecoration(new MyDividerItemDecoration(this, LinearLayoutManager.HORIZONTAL, 16));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        // row click listener
        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Poll p = pollList.get(position);
                Context context = view.getContext();
                Intent i = new Intent(context, OptionsActivity.class);
                i.putExtra("poll", p);
                context.startActivity(i);
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

       /* loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);

        loadingDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);

        loadingDialog.setMessage("Options Loading ");
        loadingDialog.show();*/

        setPollList();

        //t1.start();

        /*t2.start();
        try {
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {

            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
*/


    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
    public void pollIds() {
        database = FirebaseDatabase.getInstance();
        ref = database.getReference("usersForPoll");
        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                pollids.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Object o = postSnapshot.getValue();
                    HashMap m = (HashMap) o;
//                Collection s=m.values();
//                ArrayList theList = new ArrayList(s);

                    ArrayList<String> usersAlreadyVoted = (ArrayList<String>) m.get("usersList");
                    Object pollid = m.get("pollID");
                    String pid = String.valueOf(pollid);


                    for (int i = 0; i < usersAlreadyVoted.size(); i++) {
                        String uservoted = String.valueOf(usersAlreadyVoted.get(i));
                        if (uservoted.equals(userid)) {
                            pollids.add(pid);
                        }
                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }


        });
    }

    public void setPollList() {


        database = FirebaseDatabase.getInstance();
        ref = database.getReference("poll");
        for (int i = 0; i < pollids.size(); i++) {
            ref.orderByChild("pollID").equalTo((pollids.get(i))).addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    Poll p = new Poll();
                    Object o = dataSnapshot.getValue();
                    HashMap u = (HashMap) o;
                    Object o2 = u.get("title");
                    p.title = String.valueOf(o2);
                    o2 = u.get("details");
                    p.setDetails(String.valueOf(o2));
                    o2 = u.get("createdBy");
                    p.setCreatedBy(String.valueOf(o2));
                    o2 = u.get("endTime");
                    p.setEndTime(String.valueOf(o2));
                    o2 = u.get("startTime");
                    p.setStartTime(String.valueOf(o2));
                    o2 = u.get("pollID");
                    p.setPollID(String.valueOf(o2));
                    o2 = u.get("pollQuestion");
                    p.setPollQuestion(String.valueOf(o2));
                    pollList.add(p);
                    pAdapter.notifyDataSetChanged();
                   // loadingDialog.hide();
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }


}


