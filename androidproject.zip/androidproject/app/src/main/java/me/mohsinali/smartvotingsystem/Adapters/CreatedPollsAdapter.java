package me.mohsinali.smartvotingsystem.Adapters;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

import me.mohsinali.smartvotingsystem.Activities.HomeActivity;
import me.mohsinali.smartvotingsystem.DTO.Poll;
import me.mohsinali.smartvotingsystem.R;

public class CreatedPollsAdapter extends RecyclerView.Adapter<CreatedPollsAdapter.MyViewHolder> {
    private List<Poll> PollsList;
    private ProgressDialog progress;

    public CreatedPollsAdapter(List<Poll> PollsList) {
        this.PollsList = PollsList;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView name;
        public TextView description;
        public TextView createdby;
        public TextView id;
        public TextView question;
        public TextView startTime;
        public TextView endTime;
        public Button button;


        public MyViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.stats_createdVotes_pollname);
            description = view.findViewById(R.id.stats_createdVotes_description);
            createdby = view.findViewById(R.id.stats_createdVotes_createdby);
            id = view.findViewById(R.id.stats_createdVotes_pollid);
            question = view.findViewById(R.id.stats_createdVotes_pollQuestion);
            startTime = view.findViewById(R.id.stats_createdVotes_startTime);
            endTime = view.findViewById(R.id.stats_createdVotes_endTime);
            button = (Button) view.findViewById(R.id.stats_delete);
        }
    }


    @Override
    public CreatedPollsAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.stats_polls_cells, parent, false);

        return new CreatedPollsAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(CreatedPollsAdapter.MyViewHolder holder, int position) {

        Poll p = PollsList.get(position);
        holder.name.setText(p.getTitle());
        holder.description.setText(p.getDetails());
        holder.createdby.setText(p.getCreatedBy());
        holder.id.setText(p.getPollID());
        holder.question.setText(p.getPollQuestion());
        holder.startTime.setText(p.getStartTime());
        holder.endTime.setText(p.getEndTime());
        holder.button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //Toast.makeText(v.getContext(),"clicked",Toast.LENGTH_SHORT).show();
                Poll p1 = PollsList.get(position);
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference ref = database.getReference("poll");
                //  progress=new ProgressDialog(v.getContext());
                //  progress.setMessage("Verifying email...");
                //  progress.show();
                ref.orderByChild("pollID").equalTo(p1.getPollID()).addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        dataSnapshot.getRef().setValue(null);




                        //progress.dismiss();
                        // Intent in = new Intent(v.getContext(), ShowCreatedPollsActivity.class);
                        // v.getContext().startActivity(in);
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


                ref = database.getReference("options");

                ref.orderByChild("pollID").equalTo(p1.getPollID()).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        for(DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                            postSnapshot.getRef().setValue(null);
                        }


                        Intent i= new Intent(v.getContext(),HomeActivity.class);
                        v.getContext().startActivity(i);
 
                        Toast.makeText(v.getContext(), "Deleted", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        });


    }

    @Override
    public int getItemCount() {
        return PollsList.size();
    }
}
