package me.mohsinali.smartvotingsystem.Activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executors;

import me.mohsinali.smartvotingsystem.Adapters.CandidateAdapter;
import me.mohsinali.smartvotingsystem.DTO.Candidate;
import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

/**
 * Created by SPIDER on 5/4/2018.
 */

public class CandidateMainActivity extends AppCompatActivity {
    private List<Candidate> cnd = new ArrayList<>();
    public android.support.v7.widget.RecyclerView recyclerView;
    private CandidateAdapter cndAdapter;
    private String idOfPoll;
    public static String indexOfThePoll;
    FirebaseDatabase database;
    DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.candidatemain);
        setTitle("Options");
        idOfPoll = (String) getIntent().getExtras().get("ID");
        indexOfThePoll = (String) getIntent().getExtras().get("indexInDB");
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view_candidate);
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("options");

        cndAdapter = new CandidateAdapter(cnd, getApplicationContext(), database, myRef);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        // adding inbuilt divider line
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setLayoutManager(mLayoutManager);
        //       prepareSampleCandidateData();
        recyclerView.setAdapter(cndAdapter);
        // cndAdapter.notifyDataSetChanged();

        //  prepareSampleCandidateData(idOfPoll);
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                getDataFromDatabase();
            }
        });

    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
    private void getDataFromDatabase() {

        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                String key = dataSnapshot.getKey();
                Object o = dataSnapshot.getValue();
                HashMap u = (HashMap) o;
                Log.i("A", "onChildAdded: " + dataSnapshot);
                Candidate cnd1 = new Candidate();
                cnd1.setName((String) u.get("title"));
                cnd1.setNoOfVotes(String.valueOf(u.get("noOfVotes")));

                cnd1.setDescription((String) u.get("description"));
                cnd1.setStatus((String) u.get("status"));
//                cnd1.setId(String.valueOf(u.get("optionID")));
                cnd1.setId(key);
                String ii = String.valueOf(u.get("pollID"));
                if (String.valueOf(u.get("pollID")).equals(idOfPoll)) {
                    cnd.add(cnd1);
                    recyclerView.setAdapter(cndAdapter);
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                Object o = dataSnapshot.getValue();
                HashMap u = (HashMap) o;
                String idd=String.valueOf(u.get("pollID"));
                   if(idOfPoll.equals(idd))
                    {
                        Toast.makeText(getApplicationContext(), "MODULES UPDATED", Toast.LENGTH_SHORT).show();
                        myRef.removeEventListener(this);
                        finish();
                    }

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //   prepareSampleCandidateData((String)getIntent().getExtras().get("ID"));
    }

    private void prepareSampleCandidateData(String id) {

        if (true) {
            Candidate cnd1 = new Candidate();
            cnd1.setName("TEMP1");
            cnd1.setNoOfVotes("245");
            cnd1.setDescription("Vote for the best");
            cnd1.setStatus("Voting in progress");
            cnd1.setId("1");
            cnd.add(cnd1);
            Candidate cnd2 = new Candidate();
            cnd2.setName("TEMP2");
            cnd2.setNoOfVotes("201");
            cnd2.setDescription("Vote for the best");
            cnd2.setStatus("Voting in progress");
            cnd2.setId("1");
            cnd.add(cnd2);
        } else if (id.equals("2")) {
            Candidate cnd3 = new Candidate();
            cnd3.setName("John");
            cnd3.setNoOfVotes("211");
            cnd3.setDescription("Vote Me");
            cnd3.setStatus("Voting in progress");
            cnd3.setId("2");
            cnd.add(cnd3);
            Candidate cnd4 = new Candidate();
            cnd4.setName("Leo");
            cnd4.setNoOfVotes("301");
            cnd4.setDescription("Vote Us");
            cnd4.setStatus("Voting in progress");
            cnd4.setId("2");
            cnd.add(cnd4);
        } else if (id.equals("3")) {
            Candidate cnd5 = new Candidate();
            cnd5.setName("Lenovo Thinkpad T460s");
            cnd5.setNoOfVotes("145");
            cnd5.setDescription("Intel Lattest Processors");
            cnd5.setStatus("Voting in progress");
            cnd5.setId("3");
            cnd.add(cnd5);
            Candidate cnd6 = new Candidate();
            cnd6.setName("Mac Book Pro 2018");
            cnd6.setNoOfVotes("204");
            cnd6.setDescription("Top Tech");
            cnd6.setStatus("Voting in progress");
            cnd6.setId("3");
            cnd.add(cnd6);
        } // notify adapter about data set changes
        // so that it will render the list with new data
        cndAdapter.notifyDataSetChanged();
    }
}