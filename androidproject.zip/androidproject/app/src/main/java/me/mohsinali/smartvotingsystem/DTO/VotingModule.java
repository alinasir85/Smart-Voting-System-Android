package me.mohsinali.smartvotingsystem.DTO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by SPIDER on 5/4/2018.
 */

public class VotingModule {
    public String id;
    public String name;
    public String description;
    public String createdBy;
    public String question;
    public Date start;
    public Date end;
    public String indexInDB;
    public ArrayList usersList = new ArrayList<>();
    public ArrayList usersAlreadyVoted = new ArrayList<>();
    List<Candidate> list;

    public void setName(String n) {
        name = n;
    }

    public String getName() {
        return name;
    }

    public void setDescription(String des) {
        description = des;
    }

    public String getDescription() {
        return description;
    }

    public void setCreatedBy(String crtBy) {
        createdBy = crtBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setQuestion(String qst) {
        question = qst;
    }

    public String getQuestion() {
        return question;
    }

    public void setStartDate(Date d) {
        start = d;
    }

    public Date getStartDate() {
        return start;
    }

    public void setendDate(Date d) {
        end = d;
    }

    public Date getEndDate() {
        return end;
    }

    public void setCandidateList(List<Candidate> l) {
        list = l;
    }

    public void setId(String i) {
        id = i;
    }

    public String getId() {
        return id;
    }


}

