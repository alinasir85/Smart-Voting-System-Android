package me.mohsinali.smartvotingsystem.Activities;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DatabaseReference;

import java.util.Random;
import java.util.concurrent.Executors;

import me.mohsinali.smartvotingsystem.DTO.GMailSender;
import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

public class EmailValidationActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btn1;
    boolean s;
    boolean status;
    private ProgressDialog progress;
    DatabaseReference databaseUsers, firedatabase;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i("CHK", "AA");
        Log.e("CHK", "AA");

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_email_validation);
        setTitle("EmailVeification");
        btn1 = (Button) findViewById(R.id.verifybtn);
        btn1.setOnClickListener(this);

        preferences = PreferenceManager.getDefaultSharedPreferences(this);

    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
    @Override
    public void onClick(View v) {

        Log.i("CHK", "BB");
        Log.e("CHK", "BB");

        if (v.getId() == R.id.verifybtn) {
            progress = new ProgressDialog(EmailValidationActivity.this);
            progress.setMessage("Verifying email...");
            progress.show();

            Log.e("CHK", "CC");

            Executors.newSingleThreadExecutor().execute(new Runnable() {
                @Override
                public void run() {


                    s = sendEmail();
                    if (s == true) {
                        progress.dismiss();
                        Intent in = new Intent(EmailValidationActivity.this, CodeActivity.class);


                        startActivity(in);
                    } else {
                        new AlertDialog.Builder(EmailValidationActivity.this)

                                .setTitle("Connection")


                                .setMessage("Your email is not verified.Go back and check your email or internet connection")


                                .setCancelable(true)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent i = new Intent(EmailValidationActivity.this, EmailValidationActivity.class);

                                        startActivity(i);
                                    }


                                }).show();

                    }
                   /* if(s=="")
                    {

                       // Toast.makeText(getApplicationContext(),"Email sent",Toast.LENGTH_SHORT).show();

                        firedatabase = getInstance().getReference();
                        databaseUsers = FirebaseDatabase.getInstance().getReference("users");

                        final String id = databaseUsers.push().getKey();
                        //  int UserID=Integer.getInteger(id);

                        String name = preferences.getString("Name", "defaultValue");
                        String password = preferences.getString("Password", "defaultValue");
                        String email = preferences.getString("Email", "defaultValue");
                        String cnic = preferences.getString("CNIC", "defaultValue");
                        int age = preferences.getInt("Age", 0);
                        String picture = preferences.getString("PictureName", "defaultValue");
                        String nationality = preferences.getString("Nationality", "defaultValue");
                        String country = preferences.getString("Country", "defaultValue");
                        String city = preferences.getString("City", "defaultValue");
                        String email_cnic = preferences.getString("Email_Cnic", "defaultValue");
                        final users user = new users(name, email, city, cnic, email_cnic, country, age, nationality, password, picture, id);
                        //databaseUsers.child("2").setValue(3);
                        // Log.i("Chck", "users: "+users.geName());
                        Log.e("Chck", "email_cnic: " + email_cnic);
                        Log.e("chck", "ref : " + databaseUsers);
                        // firedatabase.child("users").child(id).setValue("3");
                        databaseUsers.orderByChild("email_cnic").equalTo(email_cnic).addListenerForSingleValueEvent(new ValueEventListener() {

                            //.orderByChild("cnic").equalTo(cnic).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                Log.e("OndataChange", "datasnapshot" + dataSnapshot);
                                if (!dataSnapshot.exists() ) {
                                    Log.e("null", "going");
                                    databaseUsers.child(id).setValue(user);
                                    Log.e("insert", "user");
                                    Intent i=new Intent(EmailValidationActivity.this,VerifiedActivity.class);
                                    Log.e("intent", "i");
                                    startActivity(i);
                                    // Toast.makeText(getApplicationContext(), "Successfully Registered", Toast.LENGTH_LONG).show();

                                }
                                else
                                {
                                    Log.e("OnChangeData", "exist");
                                    Intent i=new Intent(EmailValidationActivity.this,ExistingUserActivity.class);

                                    // preferences.edit().clear().apply();
                                    startActivity(i);

                                    //Toast.makeText(getApplicationContext(), "User Already Exists", Toast.LENGTH_LONG).show();

                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

                    }*/
                   /* else if(s=="not")
                    {

                        new AlertDialog.Builder(EmailValidationActivity.this)

                                .setTitle("Email Alert")

                                .setMessage("Your email is not verified.Go back and check your email")



                                .setCancelable(true)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent i= new Intent(EmailValidationActivity.this,RegisterActivity.class);

                                        startActivity(i);
                                    }


                                }).show();

                    }
*/


                }
            });


        }

    }

    protected boolean sendEmail() {
        try {
            Random r = new Random();
            int code = r.nextInt(1000) + 1;

            SharedPreferences.Editor ed = preferences.edit();
            ed.putInt("code", code);
            ed.commit();


            String email = preferences.getString("Email", "defaultValue");

            GMailSender sender = new GMailSender("recoverums123@gmail.com", "eadpassword");
            status = sender.sendMail("Email Verfication Code",
                    Integer.toString(code),
                    "recoverums123@gmail.com",
                    email);


        } catch (Exception e) {
            Log.e("NotSend", e.getMessage(), e);

        }
        return status;


    }
}

