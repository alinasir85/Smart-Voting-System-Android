package me.mohsinali.smartvotingsystem.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

public class EditProfileActivity extends AppCompatActivity implements View.OnClickListener {


    EditText et_name, et_password, et_email, et_age, et_nationality, et_country, et_city, et_cnic;
    private Button btn;
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference("users");
    SharedPreferences sp;
    boolean flag = false;
    String email_cnic;
    private ProgressDialog loadingDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_edit_profile);
        setTitle("Edit Profile");

        loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);

        loadingDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);


        sp = getSharedPreferences("user", Context.MODE_PRIVATE);

        et_name = (EditText) findViewById(R.id.name);
        et_password = (EditText) findViewById(R.id.password);
        et_email = (EditText) findViewById(R.id.email);
        et_age = (EditText) findViewById(R.id.age);
        et_country = (EditText) findViewById(R.id.country);
        et_city = (EditText) findViewById(R.id.city);
        et_nationality = (EditText) findViewById(R.id.nationality);

        et_cnic = (EditText) findViewById(R.id.cnic);
        findViewById(R.id.email).setEnabled(false);
        findViewById(R.id.cnic).setEnabled(false);
        btn = findViewById(R.id.btnEdit);

        btn.setOnClickListener(this);

        //Email validation
        et_email.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String e = et_email.getText().toString();
                    String validemail = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" + "\\@" + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" + "(" + "\\." + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" + ")+";
                    if (!TextUtils.isEmpty(e)) {
                        Matcher matcher = Pattern.compile(validemail).matcher(e);
                        if (!matcher.matches()) {
                            // Toast.makeText(getApplicationContext(), "Enter the correct Email", Toast.LENGTH_SHORT).show();
                            et_email.setError("Enter the correct Email");
                        }
                    }

                }
            }
        });
        //cnic vlidation
        et_cnic.addTextChangedListener(new TextWatcher() {
            int length = 0;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                String str = et_cnic.getText().toString();
                length = str.length();

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String str = et_cnic.getText().toString();
                if ((str.length() == 5 && length < str.length()) || (str.length() == 13 && length < str.length())) {
                    //checking length  for backspace.
                    et_cnic.append("-");
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

//        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser(); //get current user
        String userID = sp.getString("UserID", null);
        Toast.makeText(this, "User ID is:" + userID, Toast.LENGTH_SHORT).show();
        if (userID == null) {
            // - user is null ...launch login activity
            Toast.makeText(this, "User ID is null", Toast.LENGTH_SHORT).show();
            finish();
        }
        showData();
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }
    public void showData() {

        String password = sp.getString("Password", "");
        et_password.setText(password);

        String email = sp.getString("Email", "");
        et_email.setText(email);


        int age = sp.getInt("Age", 0);
        et_age.setText(String.valueOf(age));


        String name = sp.getString("Name", "");
        et_name.setText(name);


        String city = sp.getString("City", "");
        et_city.setText(city);


        String cnic = sp.getString("CNIC", "");
        et_cnic.setText(cnic);


        String country = sp.getString("Country", "");
        et_country.setText(country);


        String n = sp.getString("Nationality", "");
        et_nationality.setText(n);


    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnEdit) {

            String n = et_name.getText().toString();
            String p = et_password.getText().toString();
            String e = et_email.getText().toString();
            String nic = et_cnic.getText().toString();
            String a = et_age.getText().toString();
            String nat = et_nationality.getText().toString();
            String count = et_country.getText().toString();
            String cit = et_city.getText().toString();

            if (TextUtils.isEmpty(n) || TextUtils.isEmpty(p) || TextUtils.isEmpty(e) || TextUtils.isEmpty(nic) || a == "" || TextUtils.isEmpty(nat) || TextUtils.isEmpty(count) || TextUtils.isEmpty(cit)) {
                Toast.makeText(getApplicationContext(), "Fill all the space", Toast.LENGTH_SHORT).show();
            } else {


                Toast.makeText(getApplicationContext(), "DATA UPDATED", Toast.LENGTH_LONG).show();
                DatabaseReference databaseUsers = FirebaseDatabase.getInstance().getReference("users");
                String userID = sp.getString("UserID", null);

                databaseUsers.child(userID).child("age").setValue(a);
                databaseUsers.child(userID).child("city").setValue(cit);
                databaseUsers.child(userID).child("country").setValue(count);
                databaseUsers.child(userID).child("name").setValue(n);
                databaseUsers.child(userID).child("nationality").setValue(nat);
                SharedPreferences.Editor ed = sp.edit();
                ed.putString("Password", p);
                ed.putInt("Age", Integer.parseInt(a));
                ed.putString("Name", n);
                ed.putString("City", cit);
                ed.putString("Country", count);
                ed.putString("Nationality", nat);
                ed.commit();

                Toast.makeText(getApplicationContext(), "DATA UPDATED", Toast.LENGTH_LONG).show();

                finish();
                /*loadingDialog.setMessage("Saving, Please wait... ");
                loadingDialog.show();
                */

              /*  ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {

                            Object o = postSnapshot.getValue();
                            HashMap u = (HashMap) o;

                            Object o2 = u.get("userID");
                            String db_userID = String.valueOf(o2);

                            o2 = u.get("email");
                            String db_email = String.valueOf(o2);

                            o2 = u.get("cnic");
                            String db_cnic = String.valueOf(o2);


                            // skip email or nic checking of current user
                            String userID = sp.getString("UserID", "");
                            if (!TextUtils.equals(userID,db_userID)  && (db_email.equals(e) || db_cnic.equals(nic))) {
                                flag = true;
                                break;
                            }
                        }
                        if (flag == true) {
                            Intent i = new Intent(EditProfileActivity.this, ExistingUserActivity.class);
                            startActivity(i);

                        } else {
                            email_cnic = e + "_" + nic;
                            SharedPreferences.Editor ed = sp.edit();
                            ed.putString("Name", n);
                            ed.putString("Password", p);
                            ed.putString("Email", e);
                            ed.putString("CNIC", nic);
                            int ag = Integer.parseInt(et_age.getText().toString());

                            ed.putInt("Age", ag);
                            ed.putString("Nationality", nat);
                            ed.putString("Country", count);
                            ed.putString("City", cit);
                            ed.putString("Email_Cnic", email_cnic);
                            ed.commit();
                            loadingDialog.hide();

                            ref.removeEventListener(this);
                            Intent in = new Intent(EditProfileActivity.this, EmailValidationActivity.class);
                            startActivity(in);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });*/
            }
        }
    }
}