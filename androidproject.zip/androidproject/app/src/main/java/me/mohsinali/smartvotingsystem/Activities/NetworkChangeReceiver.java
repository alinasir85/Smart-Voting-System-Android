package me.mohsinali.smartvotingsystem.Activities;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;
import me.mohsinali.smartvotingsystem.Utils.OfflineDialogActivity;

public class NetworkChangeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(final Context context, final Intent intent) {

        if (NetworkUtil.getConnectivityStatus(context) == NetworkUtil.TYPE_NOT_CONNECTED) {
//            OfflineDialogActivity offlineDialogActivity = new OfflineDialogActivity();
        }
    }
}