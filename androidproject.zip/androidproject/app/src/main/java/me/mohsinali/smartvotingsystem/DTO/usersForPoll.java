package me.mohsinali.smartvotingsystem.DTO;

public class usersForPoll
{
    private String criteria;
    private int id;
    private int pollID;

    public usersForPoll() {
    }

    public usersForPoll(String criteria, int id, int pollID) {
        this.criteria = criteria;
        this.id = id;
        this.pollID = pollID;
    }

    public String getCriteria() {
        return criteria;
    }

    public void setCriteria(String criteria) {
        this.criteria = criteria;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPollID() {
        return pollID;
    }

    public void setPollID(int pollID) {
        this.pollID = pollID;
    }
}
