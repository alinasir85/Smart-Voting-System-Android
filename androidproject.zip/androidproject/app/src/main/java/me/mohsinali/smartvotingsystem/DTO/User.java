package me.mohsinali.smartvotingsystem.DTO;

/**
 * Created by Noor Fatima on 5/25/2018.
 */

public class User {
    String name, password, email, location, identification, cnic, nationality;
    boolean isEightenPlus, isEightenBelow;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public String getCnic() {
        return cnic;
    }

    public void setCnic(String cnic) {
        this.cnic = cnic;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public boolean isEightenPlus() {
        return isEightenPlus;
    }

    public void setEightenPlus(boolean eightenPlus) {
        isEightenPlus = eightenPlus;
    }

    public boolean isEightenBelow() {
        return isEightenBelow;
    }

    public void setEightenBelow(boolean eightenBelow) {
        isEightenBelow = eightenBelow;
    }
}
