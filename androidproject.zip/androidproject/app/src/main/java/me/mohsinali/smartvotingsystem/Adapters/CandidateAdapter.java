package me.mohsinali.smartvotingsystem.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.List;

import me.mohsinali.smartvotingsystem.Activities.CandidateMainActivity;
import me.mohsinali.smartvotingsystem.Activities.VotingModulesActivity;
import me.mohsinali.smartvotingsystem.DTO.Candidate;
import me.mohsinali.smartvotingsystem.R;

/**
 * Created by SPIDER on 5/4/2018.
 */

public class CandidateAdapter extends RecyclerView.Adapter<CandidateAdapter.MyViewHolder> {

    private List<Candidate> candidateList;
    FirebaseDatabase database;
    DatabaseReference myRef;
    public Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView name;
        public TextView noOfVotes;
        public TextView deescription;
        public TextView status;
        public TextView optionNo;

        public Button castVote;
        public TextView endTime;

        public MyViewHolder(View view) {
            super(view);
            name = (TextView) view.findViewById(R.id.stats_options_title_vote);
            noOfVotes = (TextView) view.findViewById(R.id.stats_options_votes_vote);
            deescription = (TextView) view.findViewById(R.id.stats_options_description_vote);
            status = (TextView) view.findViewById(R.id.stats_options_status_vote);
            optionNo = (TextView) view.findViewById(R.id.stats_options_oid_vote);
            castVote = (Button) view.findViewById(R.id.btn_castVote_vote);

        }
    }

    public CandidateAdapter(List<Candidate> cndList, Context c, FirebaseDatabase db, DatabaseReference rf) {
        database = db;
        myRef = rf;
        this.candidateList = cndList;
        context = c;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.candidatecell, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        Candidate cand = candidateList.get(position);
        String a = cand.getName();
        holder.name.setText(cand.getName());
        holder.noOfVotes.setText(cand.getNoOfVotes());
        holder.deescription.setText(cand.getDescription());
        holder.status.setText(cand.getStatus());
        holder.optionNo.setText(String.valueOf(position + 1));
        //i am using the tags to store candidate index (in DB) and noOfVotes in Button
        holder.castVote.setTag(cand.getId() + ":" + cand.getNoOfVotes());
        holder.castVote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.btn_castVote_vote) {
                    String tag = (String) view.getTag();
                    String[] sep = tag.split(":");
                    String id = sep[0];
                    String votes = sep[1];
                    //check if he is already cast vote or not?
                    if (VotingModulesActivity.usersAlreadyVoted.contains(VotingModulesActivity.loggedInUserID)) {
                        Toast.makeText(context, "You Have Already Voted in this Poll !", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(context, "Thanks for voting !", Toast.LENGTH_SHORT).show();

                        //int index = Integer.parseInt(id);
                        int noOfVotes = Integer.parseInt(votes);
                        myRef.child(id).child("noOfVotes").setValue(++noOfVotes);
                        view.setTag(id + ":" + noOfVotes);
                        VotingModulesActivity.usersAlreadyVoted.add(VotingModulesActivity.loggedInUserID);

                        HashMap<String, String> names = new HashMap();
                        for (Object currentX : VotingModulesActivity.usersAlreadyVoted) {
                            if (currentX != null) {
                                names.put(currentX.toString(), currentX.toString());
                            }
                            // Do something with the value
                        }
                        database.getReference("poll").child(CandidateMainActivity.indexOfThePoll.toString()).child("usersAlreadyVoted").setValue(names);
                    }
                }
            }
        });
        //set button

    }

    @Override
    public int getItemCount() {
        return candidateList.size();
    }
}