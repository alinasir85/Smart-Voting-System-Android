package me.mohsinali.smartvotingsystem.DTO;

import java.io.Serializable;
import java.util.List;

/**
 * Created by LINO on 01/05/2018.
 */

public class Poll implements Serializable{
    public String title;
    public String details;
    private String createdBy;
    private String endTime;
    private String startTime;
    private String pollID;
    private String pollQuestion;
    private List<String> usersList;
    private List<String> usersAlreadyVoted;

    public Poll() {
    }

    public Poll(String title, String details, String createdBy, String endTime, String startTime, String pollID, String pollQuestion) {
        this.title = title;
        this.details = details;
        this.createdBy = createdBy;
        this.endTime = endTime;
        this.startTime = startTime;
        this.pollID = pollID;
        this.pollQuestion = pollQuestion;
    }

    public List<String> getUsersList() {
        return usersList;
    }

    public void setUsersList(List<String> usersList) {
        this.usersList = usersList;
    }

    public List<String> getUsersAlreadyVoted() {
        return usersAlreadyVoted;
    }

    public void setUsersAlreadyVoted(List<String> usersAlreadyVoted) {
        this.usersAlreadyVoted = usersAlreadyVoted;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getPollID() {
        return pollID;
    }

    public void setPollID(String pollID) {
        this.pollID = pollID;
    }

    public String getPollQuestion() {
        return pollQuestion;
    }

    public void setPollQuestion(String pollQuestion) {
        this.pollQuestion = pollQuestion;
    }


}
