package me.mohsinali.smartvotingsystem.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executors;

import me.mohsinali.smartvotingsystem.Adapters.CreatedPollsAdapter;
import me.mohsinali.smartvotingsystem.DTO.Poll;
import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

/**
 * Created by LINO on 01/05/2018.
 */

public class ShowCreatedPollsActivity extends AppCompatActivity {
    private List<Poll> pollList = new ArrayList<>();
    private RecyclerView recyclerView;
    private CreatedPollsAdapter pAdapter;
    SharedPreferences sp;
    private String userid;
    private FirebaseDatabase database;
    private DatabaseReference ref;
    private ProgressDialog loadingDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stats_created_polls);
        setTitle("Created Polls");

        sp = getSharedPreferences("user", Context.MODE_PRIVATE);
        userid = sp.getString("UserID", "");

       /* loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);

        loadingDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);

        loadingDialog.setMessage("Options Loading ");
        loadingDialog.show();*/

        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                setPollList();
            }
        });


        recyclerView = findViewById(R.id.stats_polls_recycler_view);

        pAdapter = new CreatedPollsAdapter(pollList);

        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(pAdapter);
        // adding inbuilt divider line
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        // adding custom divider line with padding 16dp
        // recyclerView.addItemDecoration(new MyDividerItemDecoration(this, LinearLayoutManager.HORIZONTAL, 16));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        // row click listener
        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Poll p = pollList.get(position);
                Context context = view.getContext();
                Intent i = new Intent(context, OptionsActivity.class);
                i.putExtra("poll", p);
                context.startActivity(i);
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));


    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        NetworkUtil.canNetworkWatcherThreadKeepRunning = false;
    }

    public void setPollList() {
        database = FirebaseDatabase.getInstance();
        ref = database.getReference("poll");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                pollList.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Poll p = new Poll();
                    Object o = postSnapshot.getValue();
                    HashMap u = (HashMap) o;
                    Object o2 = u.get("createdBy");
                    String createdBy = String.valueOf(o2);
                    if (createdBy.equals(userid)) {
                        o2 = u.get("title");
                        p.title = String.valueOf(o2);
                        o2 = u.get("details");
                        p.setDetails(String.valueOf(o2));
                        o2 = u.get("createdBy");
                        p.setCreatedBy(String.valueOf(o2));
                        o2 = u.get("endTime");
                        p.setEndTime(String.valueOf(o2));
                        o2 = u.get("startTime");
                        p.setStartTime(String.valueOf(o2));
                        o2 = u.get("pollID");
                        p.setPollID(String.valueOf(o2));
                        o2 = u.get("pollQuestion");
                        p.setPollQuestion(String.valueOf(o2));
                        pollList.add(p);
                        pAdapter.notifyDataSetChanged();
                    } } }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

}

