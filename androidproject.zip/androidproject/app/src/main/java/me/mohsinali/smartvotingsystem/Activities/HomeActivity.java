package me.mohsinali.smartvotingsystem.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.util.concurrent.Executors;

import me.mohsinali.smartvotingsystem.R;
import me.mohsinali.smartvotingsystem.Utils.NetworkUtil;

/**
 * Created by Noor Fatima on 5/6/2018.
 */

public class HomeActivity extends AppCompatActivity {
    ImageView user_image;
    DrawerLayout drawer;
    NavigationView navigationView;
    Button btn_cast_vote, btn_create_poll, btn_see_statistics, btn_edit_settings, btn_edit_profile;
    String CurrentUser;
    String pic;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_main, menu);


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.menu_logout) {
            SharedPreferences sp = getSharedPreferences("user", Context.MODE_PRIVATE);
            if (sp.getString("UserID", null) != null) {
                String uID=sp.getString("UserID", null);
                SharedPreferences.Editor editor = sp.edit();
                editor.remove("UserID");
                editor.commit();

                DatabaseReference databaseUsers = FirebaseDatabase.getInstance().getReference("users");
                databaseUsers.child(uID).child("loggedin").setValue("false");


                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        } else if(item.getItemId() == R.id.menu_main_settings) {
            Intent intent = new Intent(this, EditProfileActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);
        setTitle("Home");


        user_image = findViewById(R.id.user_image_home_activity);
        btn_cast_vote = findViewById(R.id.btn_castVote_home_activity);
        btn_create_poll = findViewById(R.id.btn_create_poll_home_activity);
        btn_see_statistics = findViewById(R.id.btn_see_statistics_home_activity);
        btn_edit_settings = findViewById(R.id.btn_edit_settings_home_activity);
        btn_edit_profile = findViewById(R.id.btn_edit_profile_home_activity);

        SharedPreferences sp = getSharedPreferences("user", Context.MODE_PRIVATE);
        pic=sp.getString("Picture", "");
        //pic="359749a1-709f-4e5c-af26-231dc363cea0";

        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
               loadImage();
            }
        });



        if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().getString("CurrentUser") != null) {
            CurrentUser = getIntent().getExtras().getString("CurrentUser");
        } else {

           // SharedPreferences sp = getSharedPreferences("user", Context.MODE_PRIVATE);
            CurrentUser = sp.getString("UserID", "");
        }


        btn_create_poll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(HomeActivity.this, CreatePollActivity.class);
                startActivity(i);
            }
        });
        btn_cast_vote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(HomeActivity.this, VotingModulesActivity.class);
                startActivity(i);
            }
        });

        btn_see_statistics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(HomeActivity.this, ShowStatsActivity.class);
                startActivity(i);
            }
        });

        btn_edit_settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(HomeActivity.this, ProfileActivity.class);
                i.putExtra("CurrentUser", CurrentUser);
                i.putExtra("pictureEditMode", true);

                startActivity(i);
            }
        });
        btn_edit_profile.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(HomeActivity.this, EditProfileActivity.class);
                i.putExtra("CurrentUser", CurrentUser);
                startActivity(i);
            }
        }));
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (NetworkUtil.startActivityIfNetworkIsNotConnected(this)) {
            finish();
            return;
        }

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        SharedPreferences sp = getSharedPreferences("user", Context.MODE_PRIVATE);
        pic=sp.getString("Picture", "");

        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                loadImage();
            }
        });

    }

    @Override
    public void onBackPressed() {
       // super.onBackPressed();
        finishAffinity();
    }


    public void loadImage()
    {
        try {
            final File tmpFile = File.createTempFile("img", "png");
            StorageReference reference = FirebaseStorage.getInstance().getReference("images");

            //  "id" is name of the image file....
            String id=pic;

            reference.child(id).getFile(tmpFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {

                    Bitmap image = BitmapFactory.decodeFile(tmpFile.getAbsolutePath());

                    user_image.setImageBitmap(image);

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
